#include <stdio.h>
#include <stdlib.h>

// funcion de ejemplo
void imprimirMensaje()
{
    printf("! Hola, mundo!\n");
}

/*
    comentarios
    multilinea
*/

int main
{
    // Llamada a la funcion
    imprimirMensaje();
    return 0;
}
