

// Pepe1
//  Pepe 1

#include <stdio.h>
#include <stdlib.h>

void imprimirMensaje() // paso1: imprime mensaje en pantalla
{
    printf("! Hola, mundo!\n");
}

/*
    ahora viene el main
*/


int main // paso2: llamo a / la funcion
{
    imprimirMensaje(); 
    return 0;
}